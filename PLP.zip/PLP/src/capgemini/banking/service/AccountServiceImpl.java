package capgemini.banking.service;

import java.util.Collection;
import capgemini.banking.bean.Account;
import capgemini.banking.dao.AccountDAO;
import capgemini.banking.dao.AccountDAOImpl;
import capgemini.banking.exception.AccountNotFoundException;
import capgemini.banking.exception.InSufficientBalanceException;

public class AccountServiceImpl implements AccountService {
	AccountDAO accountDAO;

	public AccountServiceImpl(int size) {
		accountDAO = new AccountDAOImpl(size);
	}

	@Override
	public int createAccount(Account account) {
		return accountDAO.createAccount(account);
	}

	@Override
	public void deposit(int accountNo, double amount) throws AccountNotFoundException {
		accountDAO.deposit(accountNo, amount);
	}

	@Override
	public void withdraw(int accountNo, double amount) throws AccountNotFoundException, InSufficientBalanceException {
		accountDAO.withdraw(accountNo, amount);
	}

	@Override
	public void fundsTransfer(int accountNoFrom, int accountNoTo, double amount)
			throws AccountNotFoundException, InSufficientBalanceException {
		accountDAO.fundsTransfer(accountNoFrom, accountNoTo, amount);
	}

	@Override
	public double getBalance(int accountNo) throws AccountNotFoundException {
		return accountDAO.getBalance(accountNo);
	}

	@Override
	public Collection<Account> getTransactions() {
		return accountDAO.getTransactions();
	}
}
